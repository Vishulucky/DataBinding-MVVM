package com.listviewmodelandroiddatabind;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.listviewmodelandroiddatabind.adapter.CustomAdapter;
import com.listviewmodelandroiddatabind.viewmodel.ListViewModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayList<ListViewModel> newslist;
    private CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView)findViewById(R.id.listview);

        newslist = new ArrayList<>();

        ListViewModel listViewModel1 = new ListViewModel("Title1 ","This is title one","http://i.imgur.com/DvpvklR.png");
        ListViewModel listViewModel2 = new ListViewModel("Title2 ","This is title two","http://i.imgur.com/DvpvklR.png");
        ListViewModel listViewModel3 = new ListViewModel("Title3 ","This is title three","http://i.imgur.com/DvpvklR.png");


        newslist.add(listViewModel1);
        newslist.add(listViewModel2);
        newslist.add(listViewModel3);

        customAdapter = new CustomAdapter(this, newslist);
        listView.setAdapter(customAdapter);





    }
}
