package com.listviewmodelandroiddatabind.viewmodel;

import android.databinding.BaseObservable;
import android.databinding.BindingAdapter;
import android.widget.ImageView;

import com.listviewmodelandroiddatabind.R;
import com.squareup.picasso.Picasso;

/**
 * Created by lenovo on 3/5/2018.
 */

public class ListViewModel extends BaseObservable {


    public String title , desc , imagepath;

    public ListViewModel(String title, String desc, String imagepath) {
        this.title = title;
        this.desc = desc;
        this.imagepath = imagepath;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @BindingAdapter({"bind:imageUrl"})

    public static void loadImage(ImageView imageView , String imageUrl)
    {

        Picasso.with(imageView.getContext()).load(imageUrl).placeholder(R.drawable.ic_launcher_background).into(imageView);



    }

    public String getImageUrl()
    {
        return imagepath;
    }




}
