package com.listviewmodelandroiddatabind.adapter;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.listviewmodelandroiddatabind.R;
import com.listviewmodelandroiddatabind.databinding.ListViewBinding;
import com.listviewmodelandroiddatabind.viewmodel.ListViewModel;

import java.util.ArrayList;

/**
 * Created by lenovo on 3/5/2018.
 */

public class CustomAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<ListViewModel> newslist;

    private ListViewBinding listViewBinding;



    public CustomAdapter(Context context , ArrayList<ListViewModel> newslist)
    {

        this.context = context;
        this.newslist = newslist;

    }



    @Override
    public int getCount() {
        return newslist.size();
    }

    @Override
    public Object getItem(int pos) {
        return newslist.get(pos);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int pos, View convertview, ViewGroup parent) {

        if(convertview == null)
        {
            convertview = LayoutInflater.from(context).inflate(R.layout.innerlayout,null);
            listViewBinding = DataBindingUtil.bind(convertview);
            convertview.setTag(listViewBinding);


        }
        else
        {
            listViewBinding = (ListViewBinding)convertview.getTag();

        }

        listViewBinding.setNewsmodel(newslist.get(pos));
        return listViewBinding.getRoot();

    }
}
