package com.databindingloginviewmodel.model;

/**
 * Created by lenovo on 3/3/2018.
 */

public class User {
    public String email , password;

    public User() {
    }
}
