package com.databindingloginviewmodel.interfaces;

/**
 * Created by lenovo on 3/3/2018.
 */

public interface Presenters {

    public void clickLogin();
}
