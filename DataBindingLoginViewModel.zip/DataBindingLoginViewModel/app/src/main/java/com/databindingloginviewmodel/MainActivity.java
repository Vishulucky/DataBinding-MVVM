package com.databindingloginviewmodel;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.databindingloginviewmodel.databinding.ActivityMainBinding;
import com.databindingloginviewmodel.interfaces.Presenters;
import com.databindingloginviewmodel.viewmodel.LoginViewModel;

public class MainActivity extends AppCompatActivity {


    private ActivityMainBinding activityMainBinding;
    private LoginViewModel loginViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        activityMainBinding = DataBindingUtil.setContentView(this,R.layout.activity_main);

        loginViewModel = new LoginViewModel();

        activityMainBinding.setUser(loginViewModel);
        activityMainBinding.setPresenter(new Presenters() {
            @Override
            public void clickLogin() {


                String email = loginViewModel.getEmail();
                String password = loginViewModel.getPassword();
                //showToast("email "+email);
                if(!loginViewModel.isEmptyEmail(email)) {

                    showToast("please enter email");
                }
                else  if(!loginViewModel.isEmptyPass(password)) {

                    showToast("please enter password");
                }
                else if(!loginViewModel.isValidEmaillId(email))
                {
                    showToast("Enter valid mail");
                }

                else
                {
                    showToast("Login Enter");

               }

            }
        });

    }



    private void showToast(String msg)
    {

        Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
    }

}
