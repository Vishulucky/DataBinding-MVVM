package com.databindingloginviewmodel.viewmodel;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.databindingloginviewmodel.BR;
import com.databindingloginviewmodel.model.User;

import java.util.regex.Pattern;

/**
 * Created by lenovo on 3/3/2018.
 */

public class LoginViewModel extends BaseObservable {


    public String email , password;

    public LoginViewModel(User user) {

        this.email = user.email;
        this.password= user.password;
    }

    public LoginViewModel() {
    }

    @Bindable

    public String getEmail() {
        if(email == null)
            return "";
        else
            return email;
    }

    public void setEmail(String email) {
        this.email = email;
        notifyPropertyChanged(BR.email);
    }

    @Bindable
    public String getPassword() {
        if(password == null)
        {
            return "";

        }
        else
            return password;
    }

    public void setPassword(String password) {
        this.password = password;
        notifyPropertyChanged(BR.password);
    }



    public boolean isValidEmaillId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }


    public boolean isEmptyEmail(String email)
    {
        if(email.equals(""))
        {
            return false;
        }
        return true;
    }
    public boolean isEmptyPass(String password)
    {
        if(password.equals(""))
        {
            return false;
        }
        return true;
    }


}
