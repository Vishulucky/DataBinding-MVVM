package com.testprojectvolleybinding.adapters;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.testprojectvolleybinding.R;
import com.testprojectvolleybinding.databinding.UserModelBinding;
import com.testprojectvolleybinding.viewmodels.UserModel;

import java.util.ArrayList;

/**
 * Created by lenovo on 3/15/2018.
 */

public class CustomAdapter extends BaseAdapter {

    private ArrayList<UserModel> arrayList;
    private Context context;
    private UserModelBinding userModelBinding;

    public CustomAdapter(Context context, ArrayList<UserModel> arrayList)
    {

        this.context = context;
        this.arrayList = arrayList;
    }



    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return arrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertview, ViewGroup parent) {


        if(convertview == null)
        {

            convertview = LayoutInflater.from(context).inflate(R.layout.innerlayout,null);
            userModelBinding = DataBindingUtil.bind(convertview);
            convertview.setTag(userModelBinding);
        }
        else
        {
            userModelBinding = (UserModelBinding)convertview.getTag();
        }

        userModelBinding.setUsermodel(arrayList.get(position));


        return userModelBinding.getRoot();




    }





}
