package com.testprojectvolleybinding.remote.data;

import com.android.volley.VolleyError;

import org.json.JSONObject;

/**
 * Created by lenovo on 3/15/2018.
 */

public interface DataValues {

    public void setJsonDataResponse(JSONObject response);
    public void setVolleyError(VolleyError volleyError);


}
