package com.testprojectvolleybinding.presenters;

/**
 * Created by lenovo on 3/14/2018.
 */

public interface Presenter {

    public void getJsonData();
}
