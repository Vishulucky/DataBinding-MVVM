package com.testprojectvolleybinding.viewmodels;

/**
 * Created by lenovo on 3/14/2018.
 */

public class UserModel {
    public String firstname , lastname , age;

    public UserModel(String firstname, String lastname, String age) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
    }
}
