package com.testprojectvolleybinding;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.testprojectvolleybinding.adapters.CustomAdapter;
import com.testprojectvolleybinding.databinding.ActivityMainBinding;
import com.testprojectvolleybinding.presenters.Presenter;
import com.testprojectvolleybinding.remote.data.DataManger;
import com.testprojectvolleybinding.remote.data.DataValues;
import com.testprojectvolleybinding.viewmodels.UserModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {


   private ActivityMainBinding activityMainBinding;
   private DataManger dataManger;
   private ListView listView;
   private CustomAdapter customAdapter;
   private ArrayList<UserModel> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
   //     setContentView(R.layout.activity_main);


        activityMainBinding= DataBindingUtil.setContentView(this,R.layout.activity_main);

        dataManger = new DataManger(this);
        listView = (ListView)findViewById(R.id.listview);
        activityMainBinding.setPresenter(new Presenter() {
            @Override
            public void getJsonData() {

              dataManger.sendVolleyRequest(MainActivity.this, new DataValues() {
                  @Override
                  public void setJsonDataResponse(JSONObject response) {

                      UserModel userModel;
                      arrayList = new ArrayList<>();


                      try{


                          JSONArray jsonArray = response.getJSONArray("students");

                          for(int i =0 ; i <jsonArray.length() ;i++)
                          {

                              JSONObject user = jsonArray.getJSONObject(i);

                              String firstname = user.getString("firstname");
                              String lastname = user.getString("lastname");
                              String age = user.getString("age");
                              userModel = new UserModel(firstname,lastname,age);
                              arrayList.add(userModel);
                       }


                          customAdapter = new CustomAdapter(MainActivity.this,arrayList);
                          listView.setAdapter(customAdapter);



                      }
                      catch (JSONException jsonDataResponse)
                      {

                      }





                  }

                  @Override
                  public void setVolleyError(VolleyError volleyError) {

                  }
              });






            }
        });


    }

    void showData(String msg )
    {
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show();


    }

}
