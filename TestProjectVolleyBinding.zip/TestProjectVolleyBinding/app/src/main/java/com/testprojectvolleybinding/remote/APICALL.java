package com.testprojectvolleybinding.remote;

/**
 * Created by lenovo on 3/14/2018.
 */

public class APICALL {


    public static String BASEURL ="http://pastebin.com/raw/2bW31yqa";


}
