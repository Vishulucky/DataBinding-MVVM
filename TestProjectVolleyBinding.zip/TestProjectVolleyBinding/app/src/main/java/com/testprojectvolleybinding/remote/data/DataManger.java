package com.testprojectvolleybinding.remote.data;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.testprojectvolleybinding.remote.APICALL;
import com.testprojectvolleybinding.remote.VolleySingleton;

import org.json.JSONObject;

/**
 * Created by lenovo on 3/14/2018.
 */

public class DataManger  {

    private Context context;

    public DataManger(Context context)
    {

        this.context = context;
    }




    public void sendVolleyRequest(Context context , final DataValues dataValues)
    {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(APICALL.BASEURL, new JSONObject(), new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

               // showData(response.toString());

               dataValues.setJsonDataResponse(response);


            }
        }
                ,
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                       // showData(error.toString());
                        dataValues.setVolleyError(error);
                    }
                }

        );

        VolleySingleton.getInstance(context).addToRequestQueue(jsonObjectRequest);


    }
    void showData(String msg )
    {
        Toast.makeText(context,msg,Toast.LENGTH_LONG).show();


    }


}
