package com.mvvmmodelrecyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.mvvmmodelrecyclerview.adapter.CustomAdapter;
import com.mvvmmodelrecyclerview.model.News;
import com.mvvmmodelrecyclerview.viewmodel.NewsModel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CustomAdapter customAdapter;
    private List<NewsModel> newsList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView)findViewById(R.id.recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        newsList = new ArrayList<>();

        customAdapter = new CustomAdapter(newsList);
        recyclerView.setAdapter(customAdapter);
        setData();


    }

    private void setData() {

         NewsModel newsModel  = new NewsModel();
         newsModel.Title = "First Title ";
         newsModel.Desc = "This is first title ";

         newsList.add(newsModel);


        NewsModel newsModel1  = new NewsModel();
        newsModel1.Title = "Second Title ";
        newsModel1.Desc = "This is second title ";

        newsList.add(newsModel1);


    }
}
