package com.mvvmmodelrecyclerview.listeners;

/**
 * Created by lenovo on 3/8/2018.
 */

public interface ClickListener {

    public void onclickListener();
}
