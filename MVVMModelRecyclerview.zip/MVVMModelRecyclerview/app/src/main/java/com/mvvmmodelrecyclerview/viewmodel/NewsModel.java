package com.mvvmmodelrecyclerview.viewmodel;

import com.mvvmmodelrecyclerview.model.News;

/**
 * Created by lenovo on 2/17/2018.
 */

public class NewsModel  {

    public String Title , Desc;


    public NewsModel() {
    }

    public NewsModel(News news) {

        this.Title = news.Title;
        this.Desc = news.Desc;

    }
}
